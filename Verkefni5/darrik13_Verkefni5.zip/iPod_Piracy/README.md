# Copy files from Ipod's hard drive
This Python3 application will copy music files from iPod's hard drive into a target directory. <br />

## Run
To run the application do the following:

> ./copy_mp3.py -i ipod_directory -o target_output_file

* **-i** (or **--input**) is the source of the ipod directory
* **-o** (or **--ouput**) is the desired non existing output file, where the songs are copied over.
